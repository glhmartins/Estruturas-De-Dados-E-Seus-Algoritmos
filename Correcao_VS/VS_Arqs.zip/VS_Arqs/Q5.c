#include "TH.h"

void misc(char *arq1, char *arq2, char *saida, int k){
}

int main(void){
  int num;
  char nome_dados1[31];
  printf("Digite nome do primeiro arquivo... ");
  scanf("%s", nome_dados1);
  FILE *fp = fopen(nome_dados1, "wb");
  if(!fp) exit(1);  
  printf("Digite um numero... NAO digite numeros repetidos... Para interromper insira um numero negativo...\n");
  do{
    scanf("%d", &num);
    if(num < 0) break;
    fwrite(&num, sizeof(int), 1, fp);
  }while(1);
  fclose(fp);
  
  char nome_dados2[31];
  printf("Digite nome do segundo arquivo... ");
  scanf("%s", nome_dados2);
  fp = fopen(nome_dados2, "wb");
  if(!fp) exit(1);
  printf("Digite um numero... NAO digite numeros repetidos... Para interromper insira um numero negativo...\n");
  do{
    scanf("%d", &num);
    if(num < 0) break;
    fwrite(&num, sizeof(int), 1, fp);
  }while(1);
  fclose(fp);

  char nome_saida[31];
  printf("Digite nome do arquivo de saida... ");
  scanf("%s", nome_saida);
  int k;
  printf("Digite k... ");
  scanf("%d", &k);
  misc(nome_dados1, nome_dados2, nome_saida, k);
  
  fp = fopen(nome_saida, "rb");
  if(!fp) exit(1);
  int r, x, y;
  do{
    r = fread(&x, sizeof(int), 1, fp);
    if(r != 1) break;
    r = fread(&y, sizeof(int), 1, fp);
    if(r != 1) break;
    printf("(%d,%d)\n", x, y);
  }while(1);
  fclose(fp);

  return 0;
}
