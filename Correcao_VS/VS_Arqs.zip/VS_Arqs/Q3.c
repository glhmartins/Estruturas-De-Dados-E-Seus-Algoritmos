#include <limits.h>
#include "TARVBM.h"

//char* codif (TARVBM* a, int k);

int main(int argc, char *argv[]){
  TARVBM *arvore = TARVBM_inicializa();
  int t;
  do{
    printf("t = ");
    scanf("%d", &t);
  }while((t < 2) || (t > 5));

  int num;
  do{
    scanf("%d", &num);
    if(num <= 0) break;
    arvore = TARVBM_insere(arvore, num, t);
  }while(1);
  TARVBM_imprime(arvore);
  
  if(arvore){
    char repete;
    do{
      scanf("%d", &num);
      /*
      char *resp = codif (arvore, num);
      printf("%s\n", resp);
      free(resp);
      */
      printf("Quer continuar? ");
      scanf(" %c", &repete);
    }while((repete != 'N') && (repete != 'n'));
  }
  TARVBM_libera(arvore);
  return 0;
}
